"""
Student Performance Prediction System
======================================
Predicts students at risk of failing using ML models.
Tech Stack: Python, Pandas, Scikit-learn, OpenPyXL
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, classification_report, confusion_matrix,
    roc_auc_score, precision_score, recall_score, f1_score
)
from sklearn.pipeline import Pipeline
import warnings
warnings.filterwarnings("ignore")

# ─────────────────────────────────────────────────────────
# 1. SYNTHETIC DATASET GENERATION
# ─────────────────────────────────────────────────────────

np.random.seed(42)
N = 500

def generate_dataset(n=N):
    socio = np.random.choice([0, 1, 2], n, p=[0.3, 0.45, 0.25])  # 0=Low,1=Mid,2=High
    attendance = np.clip(
        60 + socio * 8 + np.random.normal(0, 12, n), 30, 100
    )
    study_hours = np.clip(
        1 + socio * 1.5 + attendance * 0.05 + np.random.normal(0, 1.5, n), 0, 12
    )
    prev_grade = np.clip(
        40 + socio * 12 + study_hours * 3 + np.random.normal(0, 10, n), 0, 100
    )
    parental_edu = np.random.choice([0, 1, 2], n, p=[0.25, 0.45, 0.30])
    internet = (socio + np.random.randint(0, 2, n) > 0).astype(int)
    extracurricular = np.random.choice([0, 1], n, p=[0.4, 0.6])
    absences = np.clip(
        20 - attendance * 0.15 + np.random.normal(0, 3, n), 0, 30
    ).astype(int)
    tutoring = (study_hours > 4).astype(int)
    health = np.random.choice([1, 2, 3, 4, 5], n)

    # Risk score → final grade
    # Composite score (higher = worse performance)
    risk_score = (
        (100 - attendance) * 0.35
        + (12 - study_hours) * 1.5
        + (100 - prev_grade) * 0.25
        + absences * 1.2
        + (2 - socio) * 3
        + np.random.normal(0, 8, n)
    )
    # Normalize 0-100 and threshold at 50 → ~30% at risk
    risk_norm = (risk_score - risk_score.min()) / (risk_score.max() - risk_score.min()) * 100
    final_grade = np.clip(100 - risk_norm + np.random.normal(0, 5, n), 0, 100)
    at_risk = (final_grade < 45).astype(int)  # 1 = at risk / fail

    df = pd.DataFrame({
        "Student_ID":        [f"STU{str(i+1).zfill(4)}" for i in range(n)],
        "Attendance_%":      attendance.round(1),
        "Study_Hours_Week":  study_hours.round(1),
        "Previous_Grade":    prev_grade.round(1),
        "Socioeconomic":     pd.Categorical(
                                 [["Low","Medium","High"][s] for s in socio],
                                 categories=["Low","Medium","High"], ordered=True),
        "Parental_Education":pd.Categorical(
                                 [["None","HighSchool","College"][p] for p in parental_edu],
                                 categories=["None","HighSchool","College"], ordered=True),
        "Internet_Access":   internet,
        "Extracurricular":   extracurricular,
        "Absences":          absences,
        "Tutoring_Support":  tutoring,
        "Health_Score":      health,
        "Final_Grade":       final_grade.round(1),
        "At_Risk":           at_risk,
    })
    return df

df = generate_dataset()
print(f"✅ Dataset: {df.shape[0]} students | At-risk: {df['At_Risk'].sum()} ({df['At_Risk'].mean()*100:.1f}%)")

# ─────────────────────────────────────────────────────────
# 2. FEATURE ENGINEERING
# ─────────────────────────────────────────────────────────

le = LabelEncoder()
df["Socioeconomic_enc"]      = le.fit_transform(df["Socioeconomic"])
df["Parental_Education_enc"] = le.fit_transform(df["Parental_Education"])

FEATURES = [
    "Attendance_%", "Study_Hours_Week", "Previous_Grade",
    "Socioeconomic_enc", "Parental_Education_enc",
    "Internet_Access", "Extracurricular", "Absences",
    "Tutoring_Support", "Health_Score"
]
TARGET = "At_Risk"

X = df[FEATURES]
y = df[TARGET]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# ─────────────────────────────────────────────────────────
# 3. MODEL TRAINING
# ─────────────────────────────────────────────────────────

models = {
    "Logistic Regression": Pipeline([
        ("scaler", StandardScaler()),
        ("clf", LogisticRegression(max_iter=1000, class_weight="balanced", random_state=42))
    ]),
    "Decision Tree": Pipeline([
        ("clf", DecisionTreeClassifier(max_depth=6, class_weight="balanced",
                                       min_samples_split=10, random_state=42))
    ]),
    "Random Forest": Pipeline([
        ("clf", RandomForestClassifier(n_estimators=200, max_depth=8,
                                       class_weight="balanced",
                                       min_samples_split=5, random_state=42))
    ]),
}

cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
results = {}

for name, pipe in models.items():
    pipe.fit(X_train, y_train)
    y_pred  = pipe.predict(X_test)
    y_proba = pipe.predict_proba(X_test)[:, 1]

    cv_scores = cross_val_score(pipe, X, y, cv=cv, scoring="f1")

    results[name] = {
        "model":       pipe,
        "y_pred":      y_pred,
        "y_proba":     y_proba,
        "Accuracy":    accuracy_score(y_test, y_pred),
        "Precision":   precision_score(y_test, y_pred),
        "Recall":      recall_score(y_test, y_pred),
        "F1":          f1_score(y_test, y_pred),
        "ROC_AUC":     roc_auc_score(y_test, y_proba),
        "CV_F1_Mean":  cv_scores.mean(),
        "CV_F1_Std":   cv_scores.std(),
        "CM":          confusion_matrix(y_test, y_pred),
    }
    print(f"\n{'='*45}")
    print(f"  {name}")
    print(f"  Accuracy : {results[name]['Accuracy']:.4f}")
    print(f"  Precision: {results[name]['Precision']:.4f}")
    print(f"  Recall   : {results[name]['Recall']:.4f}")
    print(f"  F1-Score : {results[name]['F1']:.4f}")
    print(f"  ROC-AUC  : {results[name]['ROC_AUC']:.4f}")
    print(f"  CV F1    : {results[name]['CV_F1_Mean']:.4f} ± {results[name]['CV_F1_Std']:.4f}")

# Best model
best_name = max(results, key=lambda k: results[k]["ROC_AUC"])
best      = results[best_name]
print(f"\n🏆 Best Model: {best_name}  (ROC-AUC = {best['ROC_AUC']:.4f})")

# ─────────────────────────────────────────────────────────
# 4. FEATURE IMPORTANCE (from Random Forest)
# ─────────────────────────────────────────────────────────

rf_model = results["Random Forest"]["model"].named_steps["clf"]
feat_imp  = pd.DataFrame({
    "Feature":    FEATURES,
    "Importance": rf_model.feature_importances_
}).sort_values("Importance", ascending=False).reset_index(drop=True)

# ─────────────────────────────────────────────────────────
# 5. AT-RISK STUDENT IDENTIFICATION
# ─────────────────────────────────────────────────────────

# Use the best model to score ALL students
best_pipe   = results[best_name]["model"]
df["Risk_Probability"] = best_pipe.predict_proba(X)[:, 1]
df["Predicted_At_Risk"] = best_pipe.predict(X)
df["Risk_Level"] = pd.cut(
    df["Risk_Probability"],
    bins=[0, 0.35, 0.60, 0.80, 1.0],
    labels=["Low", "Moderate", "High", "Critical"]
)

at_risk_students = df[df["Predicted_At_Risk"] == 1].sort_values(
    "Risk_Probability", ascending=False
).reset_index(drop=True)

print(f"\n⚠️  At-Risk Students Identified: {len(at_risk_students)}")
print(at_risk_students[["Student_ID","Risk_Level","Risk_Probability",
                         "Attendance_%","Study_Hours_Week","Previous_Grade"]].head(10).to_string(index=False))

# ─────────────────────────────────────────────────────────
# 6. EXPORT EVERYTHING TO EXCEL
# ─────────────────────────────────────────────────────────

from openpyxl import Workbook
from openpyxl.styles import (Font, PatternFill, Alignment, Border, Side,
                              GradientFill)
from openpyxl.utils import get_column_letter
from openpyxl.formatting.rule import ColorScaleRule, DataBarRule
from openpyxl.chart import BarChart, Reference
from openpyxl.chart.series import DataPoint

wb = Workbook()

# ── Palette ────────────────────────────────────────────
DARK_BLUE  = "1B3A6B"
MID_BLUE   = "2E6DB4"
LIGHT_BLUE = "D6E4F0"
ACCENT     = "E74C3C"
GREEN      = "27AE60"
ORANGE     = "E67E22"
YELLOW_BG  = "FFF9C4"
WHITE      = "FFFFFF"
GRAY_BG    = "F5F7FA"
GRAY_LINE  = "DEE2E6"

def hdr(cell, text, bold=True, fg=WHITE, bg=DARK_BLUE, size=11, wrap=False, center=True):
    cell.value = text
    cell.font  = Font(bold=bold, color=fg, size=size, name="Arial")
    cell.fill  = PatternFill("solid", fgColor=bg)
    cell.alignment = Alignment(
        horizontal="center" if center else "left",
        vertical="center", wrap_text=wrap
    )

def val(cell, text, bold=False, fg="000000", bg=None, center=True, size=10, wrap=False):
    cell.value = text
    cell.font  = Font(bold=bold, color=fg, size=size, name="Arial")
    if bg:
        cell.fill = PatternFill("solid", fgColor=bg)
    cell.alignment = Alignment(
        horizontal="center" if center else "left",
        vertical="center", wrap_text=wrap
    )

def border_range(ws, min_row, max_row, min_col, max_col, color=GRAY_LINE):
    thin = Side(style="thin", color=color)
    for row in ws.iter_rows(min_row=min_row, max_row=max_row,
                            min_col=min_col, max_col=max_col):
        for cell in row:
            cell.border = Border(left=thin, right=thin, top=thin, bottom=thin)

def set_widths(ws, widths):
    for col, w in widths.items():
        ws.column_dimensions[col].width = w

# ═══════════════════════════════════════════════════════
# SHEET 1: Dashboard / Summary
# ═══════════════════════════════════════════════════════
ws1 = wb.active
ws1.title = "📊 Dashboard"
ws1.sheet_view.showGridLines = False
ws1.row_dimensions[1].height = 50

# Title banner
ws1.merge_cells("A1:J1")
c = ws1["A1"]
c.value = "🎓  STUDENT PERFORMANCE PREDICTION SYSTEM"
c.font  = Font(bold=True, size=18, color=WHITE, name="Arial")
c.fill  = PatternFill("solid", fgColor=DARK_BLUE)
c.alignment = Alignment(horizontal="center", vertical="center")

ws1.merge_cells("A2:J2")
c = ws1["A2"]
c.value = f"Best Model: {best_name}  |  Dataset: {N} Students  |  Features: {len(FEATURES)}"
c.font  = Font(bold=False, size=11, color=WHITE, name="Arial")
c.fill  = PatternFill("solid", fgColor=MID_BLUE)
c.alignment = Alignment(horizontal="center", vertical="center")

# KPI boxes (row 4–8)
ws1.row_dimensions[4].height = 20
kpis = [
    ("Total Students", N, DARK_BLUE),
    ("At-Risk Identified", len(at_risk_students), ACCENT),
    ("Safe Students", N - len(at_risk_students), GREEN),
    ("Model Accuracy", f"{best['Accuracy']*100:.1f}%", MID_BLUE),
    ("ROC-AUC Score", f"{best['ROC_AUC']:.3f}", ORANGE),
]

col_positions = [1, 3, 5, 7, 9]  # A, C, E, G, I
for (label, kval, color), col in zip(kpis, col_positions):
    end_col = col + 1
    ws1.merge_cells(
        start_row=4, start_column=col, end_row=4, end_column=end_col
    )
    ws1.merge_cells(
        start_row=5, start_column=col, end_row=7, end_column=end_col
    )
    ws1.merge_cells(
        start_row=8, start_column=col, end_row=8, end_column=end_col
    )
    lc = ws1.cell(row=4, column=col)
    lc.value = label
    lc.font  = Font(bold=True, size=9, color=WHITE, name="Arial")
    lc.fill  = PatternFill("solid", fgColor=color)
    lc.alignment = Alignment(horizontal="center", vertical="center")

    vc = ws1.cell(row=5, column=col)
    vc.value = kval
    vc.font  = Font(bold=True, size=22, color=color, name="Arial")
    vc.fill  = PatternFill("solid", fgColor=WHITE)
    vc.alignment = Alignment(horizontal="center", vertical="center")
    ws1.row_dimensions[5].height = 40
    ws1.row_dimensions[6].height = 30
    ws1.row_dimensions[7].height = 30

# Model comparison table
ws1.merge_cells("A10:J10")
hdr(ws1["A10"], "MODEL COMPARISON", size=12, bg=DARK_BLUE)
ws1.row_dimensions[10].height = 28

headers = ["Model", "Accuracy", "Precision", "Recall",
           "F1-Score", "ROC-AUC", "CV F1 Mean", "CV F1 Std", "TP", "FP"]
for ci, h in enumerate(headers, 1):
    hdr(ws1.cell(11, ci), h, bg=MID_BLUE, size=10)

for ri, (mname, mres) in enumerate(results.items(), 12):
    cm = mres["CM"]
    row_data = [
        mname,
        f"{mres['Accuracy']:.4f}",
        f"{mres['Precision']:.4f}",
        f"{mres['Recall']:.4f}",
        f"{mres['F1']:.4f}",
        f"{mres['ROC_AUC']:.4f}",
        f"{mres['CV_F1_Mean']:.4f}",
        f"{mres['CV_F1_Std']:.4f}",
        str(cm[1][1]),
        str(cm[0][1]),
    ]
    bg = LIGHT_BLUE if mname == best_name else (WHITE if ri % 2 == 0 else GRAY_BG)
    for ci, rv in enumerate(row_data, 1):
        c = ws1.cell(ri, ci)
        val(c, rv, bg=bg, bold=(mname == best_name))
        if mname == best_name and ci == 1:
            c.value = f"🏆 {rv}"

border_range(ws1, 11, 11 + len(results), 1, len(headers))

# Risk distribution
ws1.merge_cells("A17:J17")
hdr(ws1["A17"], "RISK LEVEL DISTRIBUTION", size=12, bg=DARK_BLUE)
ws1.row_dimensions[17].height = 28

risk_dist = df["Risk_Level"].value_counts().reindex(
    ["Critical","High","Moderate","Low"], fill_value=0
)
risk_colors = {"Critical": ACCENT, "High": ORANGE, "Moderate": "F4D03F", "Low": GREEN}
hdr(ws1.cell(18, 1), "Risk Level", bg=MID_BLUE)
hdr(ws1.cell(18, 2), "Count", bg=MID_BLUE)
hdr(ws1.cell(18, 3), "Percentage", bg=MID_BLUE)
hdr(ws1.cell(18, 4), "Bar", bg=MID_BLUE)

for ri, (rl, cnt) in enumerate(risk_dist.items(), 19):
    pct = cnt / N * 100
    ws1.cell(ri, 1).value = rl
    ws1.cell(ri, 1).font  = Font(bold=True, color=WHITE, name="Arial", size=10)
    ws1.cell(ri, 1).fill  = PatternFill("solid", fgColor=risk_colors[rl])
    ws1.cell(ri, 1).alignment = Alignment(horizontal="center", vertical="center")
    val(ws1.cell(ri, 2), cnt)
    val(ws1.cell(ri, 3), f"{pct:.1f}%")
    bar_len = int(pct / 2)
    ws1.cell(ri, 4).value = "█" * bar_len
    ws1.cell(ri, 4).font  = Font(color=risk_colors[rl], name="Arial", size=10)
    ws1.cell(ri, 4).alignment = Alignment(horizontal="left", vertical="center")

border_range(ws1, 18, 22, 1, 4)

set_widths(ws1, {
    "A": 22, "B": 14, "C": 14, "D": 14,
    "E": 14, "F": 14, "G": 14, "H": 14, "I": 14, "J": 14
})

# ═══════════════════════════════════════════════════════
# SHEET 2: Dataset
# ═══════════════════════════════════════════════════════
ws2 = wb.create_sheet("📋 Dataset")
ws2.sheet_view.showGridLines = False

ws2.merge_cells("A1:N1")
hdr(ws2["A1"], "STUDENT ACADEMIC RECORDS", size=14)
ws2.row_dimensions[1].height = 35

export_cols = ["Student_ID","Attendance_%","Study_Hours_Week","Previous_Grade",
               "Socioeconomic","Parental_Education","Internet_Access","Extracurricular",
               "Absences","Tutoring_Support","Health_Score","Final_Grade",
               "Risk_Probability","Risk_Level"]
col_headers = ["Student ID","Attendance %","Study Hrs/Wk","Prev Grade",
               "Socioeconomic","Parental Edu","Internet","Extracurricular",
               "Absences","Tutoring","Health","Final Grade","Risk Prob","Risk Level"]

for ci, h in enumerate(col_headers, 1):
    hdr(ws2.cell(2, ci), h, bg=MID_BLUE, size=9, wrap=True)

for ri, row in df[export_cols].iterrows():
    excel_row = ri + 3
    risk_lvl = str(row["Risk_Level"])
    bg = WHITE if (ri % 2 == 0) else GRAY_BG
    if risk_lvl == "Critical": bg = "FFEBEE"
    elif risk_lvl == "High": bg = "FFF3E0"

    for ci, (col, v) in enumerate(zip(export_cols, row), 1):
        c = ws2.cell(excel_row, ci)
        if col == "Risk_Probability":
            val(c, round(float(v), 3), bg=bg)
        elif col == "Risk_Level":
            c.value = str(v)
            c.font  = Font(
                bold=True, size=9, name="Arial",
                color={"Critical": ACCENT, "High": ORANGE,
                       "Moderate": "856404", "Low": GREEN}.get(str(v), "000000")
            )
            c.fill = PatternFill("solid", fgColor=bg)
            c.alignment = Alignment(horizontal="center", vertical="center")
        else:
            val(c, str(v) if isinstance(v, (str,)) else v, bg=bg, size=9)

# Conditional formatting on Attendance
from openpyxl.formatting.rule import ColorScaleRule
ws2.conditional_formatting.add(
    f"B3:B{N+2}",
    ColorScaleRule(
        start_type="min", start_color="FFCDD2",
        mid_type="percentile", mid_value=50, mid_color="FFF9C4",
        end_type="max", end_color="C8E6C9"
    )
)

set_widths(ws2, {
    "A":12,"B":12,"C":13,"D":11,"E":13,"F":13,
    "G":10,"H":14,"I":10,"J":10,"K":10,"L":12,"M":11,"N":11
})

# ═══════════════════════════════════════════════════════
# SHEET 3: At-Risk Students
# ═══════════════════════════════════════════════════════
ws3 = wb.create_sheet("⚠️ At-Risk Students")
ws3.sheet_view.showGridLines = False

ws3.merge_cells("A1:K1")
c = ws3["A1"]
c.value = f"⚠️  AT-RISK STUDENTS — Requires Immediate Intervention  ({len(at_risk_students)} Students)"
c.font  = Font(bold=True, size=13, color=WHITE, name="Arial")
c.fill  = PatternFill("solid", fgColor=ACCENT)
c.alignment = Alignment(horizontal="center", vertical="center")
ws3.row_dimensions[1].height = 35

at_risk_cols = ["Student_ID","Risk_Level","Risk_Probability","Attendance_%",
                "Study_Hours_Week","Previous_Grade","Absences","Socioeconomic",
                "Parental_Education","Tutoring_Support","Internet_Access"]
at_risk_hdrs = ["Student ID","Risk Level","Risk Prob","Attendance %",
                "Study Hrs/Wk","Prev Grade","Absences","Socioeconomic",
                "Parental Edu","Tutoring","Internet"]

for ci, h in enumerate(at_risk_hdrs, 1):
    hdr(ws3.cell(2, ci), h, bg=ACCENT, size=9)

for ri, row in at_risk_students[at_risk_cols].iterrows():
    excel_row = ri + 3
    rl = str(row["Risk_Level"])
    bg = "FFEBEE" if rl == "Critical" else "FFF3E0"
    for ci, (col, v) in enumerate(zip(at_risk_cols, row), 1):
        c = ws3.cell(excel_row, ci)
        if col == "Risk_Probability":
            val(c, round(float(v), 3), bg=bg, bold=True,
                fg=ACCENT if float(v) > 0.8 else ORANGE)
        elif col == "Risk_Level":
            c.value = rl
            c.font  = Font(bold=True, size=9, name="Arial",
                           color=ACCENT if rl == "Critical" else ORANGE)
            c.fill  = PatternFill("solid", fgColor=bg)
            c.alignment = Alignment(horizontal="center", vertical="center")
        else:
            val(c, v, bg=bg, size=9)

set_widths(ws3, {
    "A":12,"B":11,"C":11,"D":12,"E":13,"F":11,"G":10,
    "H":13,"I":13,"J":10,"K":10
})

# ═══════════════════════════════════════════════════════
# SHEET 4: Feature Importance
# ═══════════════════════════════════════════════════════
ws4 = wb.create_sheet("🔍 Feature Importance")
ws4.sheet_view.showGridLines = False

ws4.merge_cells("A1:F1")
hdr(ws4["A1"], "FEATURE IMPORTANCE — Random Forest", size=13)
ws4.row_dimensions[1].height = 35

hdr(ws4.cell(2, 1), "Rank",      bg=MID_BLUE)
hdr(ws4.cell(2, 2), "Feature",   bg=MID_BLUE)
hdr(ws4.cell(2, 3), "Importance",bg=MID_BLUE)
hdr(ws4.cell(2, 4), "% Share",   bg=MID_BLUE)
hdr(ws4.cell(2, 5), "Bar Chart", bg=MID_BLUE)
hdr(ws4.cell(2, 6), "Category",  bg=MID_BLUE)

feat_category = {
    "Attendance_%":        "Engagement",
    "Study_Hours_Week":    "Study Habits",
    "Previous_Grade":      "Academic",
    "Absences":            "Engagement",
    "Socioeconomic_enc":   "Socioeconomic",
    "Parental_Education_enc": "Socioeconomic",
    "Internet_Access":     "Resources",
    "Extracurricular":     "Engagement",
    "Tutoring_Support":    "Resources",
    "Health_Score":        "Wellbeing",
}

for ri, row in feat_imp.iterrows():
    er = ri + 3
    imp = row["Importance"]
    pct = imp * 100
    bg = LIGHT_BLUE if ri < 3 else (WHITE if ri % 2 == 0 else GRAY_BG)
    val(ws4.cell(er, 1), ri + 1, bg=bg, bold=(ri < 3))
    val(ws4.cell(er, 2), row["Feature"], bg=bg, center=False, bold=(ri < 3))
    val(ws4.cell(er, 3), round(imp, 4), bg=bg)
    val(ws4.cell(er, 4), f"{pct:.1f}%", bg=bg)
    bar = "▓" * int(pct * 2.5)
    ws4.cell(er, 5).value = bar
    ws4.cell(er, 5).font  = Font(color=MID_BLUE, size=10, name="Arial")
    ws4.cell(er, 5).fill  = PatternFill("solid", fgColor=bg)
    ws4.cell(er, 5).alignment = Alignment(horizontal="left", vertical="center")
    val(ws4.cell(er, 6), feat_category.get(row["Feature"],"Other"), bg=bg)

border_range(ws4, 2, 2 + len(feat_imp), 1, 6)
set_widths(ws4, {"A":7,"B":24,"C":13,"D":12,"E":28,"F":16})

# ═══════════════════════════════════════════════════════
# SHEET 5: Model Metrics Detail
# ═══════════════════════════════════════════════════════
ws5 = wb.create_sheet("📈 Model Metrics")
ws5.sheet_view.showGridLines = False

ws5.merge_cells("A1:H1")
hdr(ws5["A1"], "DETAILED MODEL PERFORMANCE METRICS", size=13)
ws5.row_dimensions[1].height = 35

for mrow, (mname, mres) in enumerate(results.items()):
    base = mrow * 14 + 2

    ws5.merge_cells(f"A{base}:H{base}")
    hdr(ws5[f"A{base}"], f"{'🏆 ' if mname==best_name else ''}  {mname}",
        size=12, bg=(MID_BLUE if mname == best_name else "5D6D7E"))
    ws5.row_dimensions[base].height = 28

    # Metrics
    metric_headers = ["Accuracy","Precision","Recall","F1","ROC-AUC","CV F1 Mean","CV F1 Std"]
    for ci, h in enumerate(metric_headers, 1):
        hdr(ws5.cell(base+1, ci), h, bg=LIGHT_BLUE, fg=DARK_BLUE, size=9)
    metric_vals = [mres["Accuracy"], mres["Precision"], mres["Recall"],
                   mres["F1"], mres["ROC_AUC"], mres["CV_F1_Mean"], mres["CV_F1_Std"]]
    for ci, v in enumerate(metric_vals, 1):
        val(ws5.cell(base+2, ci), round(v, 4), bold=True,
            fg=(GREEN if v > 0.8 else (ORANGE if v > 0.65 else ACCENT)))

    # Confusion matrix
    ws5.cell(base+4, 1).value = "Confusion Matrix"
    ws5.cell(base+4, 1).font  = Font(bold=True, size=10, name="Arial")
    cm = mres["CM"]
    labels = [["TN","FP"],["FN","TP"]]
    colors_cm = [[GREEN, ORANGE],[ACCENT, MID_BLUE]]
    for ri2 in range(2):
        for ci2 in range(2):
            c = ws5.cell(base+5+ri2, ci2+2)
            c.value = cm[ri2][ci2]
            c.font  = Font(bold=True, color=WHITE, size=13, name="Arial")
            c.fill  = PatternFill("solid", fgColor=colors_cm[ri2][ci2])
            c.alignment = Alignment(horizontal="center", vertical="center")
            ws5.row_dimensions[base+5+ri2].height = 30
            label_c = ws5.cell(base+5+ri2, ci2+4)
            label_c.value = f"{labels[ri2][ci2]}: {cm[ri2][ci2]}"
            label_c.font  = Font(size=10, name="Arial",
                                 color=colors_cm[ri2][ci2], bold=True)

    ws5.cell(base+5, 1).value = "Actual: Negative"
    ws5.cell(base+6, 1).value = "Actual: Positive"
    for r2 in [base+5, base+6]:
        ws5.cell(r2, 1).font = Font(size=9, name="Arial", color="5D6D7E")

    ws5.cell(base+4, 2).value = "Pred: Neg"
    ws5.cell(base+4, 3).value = "Pred: Pos"
    for c2 in [2, 3]:
        ws5.cell(base+4, c2).font = Font(size=9, italic=True, name="Arial")

border_range(ws5, 2, 2 + len(results)*14, 1, 8)
set_widths(ws5, {"A":18,"B":14,"C":14,"D":14,"E":14,"F":14,"G":14,"H":14})

# ═══════════════════════════════════════════════════════
# SHEET 6: Intervention Recommendations
# ═══════════════════════════════════════════════════════
ws6 = wb.create_sheet("💡 Interventions")
ws6.sheet_view.showGridLines = False

ws6.merge_cells("A1:F1")
hdr(ws6["A1"], "INTERVENTION STRATEGY & RECOMMENDATIONS", size=13)
ws6.row_dimensions[1].height = 35

interventions = [
    ("Critical", "> 80%", "Immediate 1-on-1 counselling, daily attendance monitoring, dedicated tutor assignment, parent meeting within 48 hrs"),
    ("High",     "60-80%", "Weekly progress reviews, study group enrollment, attendance alerts at 75%, scholarship/support access check"),
    ("Moderate", "35-60%", "Bi-weekly check-ins, peer mentorship, optional tutoring sessions, teacher flagging"),
    ("Low",      "< 35%", "Regular monitoring, encourage extracurricular activities, periodic academic advisor check"),
]

inter_hdrs = ["Risk Level","Probability Range","Recommended Actions","Lead Responsible","Timeline","Priority"]
for ci, h in enumerate(inter_hdrs, 1):
    hdr(ws6.cell(2, ci), h, bg=MID_BLUE, size=9)

extra_detail = [
    ("Counsellor + HOD", "Within 48 hrs", "🔴 CRITICAL"),
    ("Class Teacher + Tutor", "Within 1 week", "🟠 HIGH"),
    ("Class Teacher", "Within 2 weeks", "🟡 MODERATE"),
    ("Academic Advisor", "Monthly", "🟢 LOW"),
]
bg_map = ["FFEBEE","FFF3E0","FFFDE7","E8F5E9"]
fg_map = [ACCENT, ORANGE, "856404", GREEN]

for ri, ((rl, prob, action), (lead, timeline, priority), bg) in enumerate(
    zip(interventions, extra_detail, bg_map), 3
):
    ws6.cell(ri, 1).value = rl
    ws6.cell(ri, 1).font  = Font(bold=True, size=10, color=WHITE, name="Arial")
    ws6.cell(ri, 1).fill  = PatternFill("solid", fgColor=fg_map[ri-3])
    ws6.cell(ri, 1).alignment = Alignment(horizontal="center", vertical="center")
    for ci, v in enumerate([prob, action, lead, timeline, priority], 2):
        c = ws6.cell(ri, ci)
        val(c, v, bg=bg, center=(ci != 3), wrap=(ci == 3), size=9)
    ws6.row_dimensions[ri].height = 45

border_range(ws6, 2, 6, 1, 6)

# Feature-based recommendations
ws6.merge_cells("A8:F8")
hdr(ws6["A8"], "TOP RISK FACTORS & TARGETED ACTIONS (Based on Feature Importance)", size=11, bg=DARK_BLUE)
ws6.row_dimensions[8].height = 28

factor_hdrs = ["Feature","Importance","If Low/Poor → Action"]
hdr(ws6.cell(9, 1), "Feature", bg=MID_BLUE)
hdr(ws6.cell(9, 2), "Importance", bg=MID_BLUE)
ws6.merge_cells("C9:F9")
hdr(ws6.cell(9, 3), "If Low/Poor → Recommended Action", bg=MID_BLUE)

suggestions = {
    "Previous_Grade":      "Enroll in remedial classes; review curriculum gaps",
    "Attendance_%":        "Send automated alerts; assign attendance buddy",
    "Absences":            "Investigate cause; medical/personal support referral",
    "Study_Hours_Week":    "Structured study timetable; library access extension",
    "Socioeconomic_enc":   "Financial aid, free meal programme, transport subsidy",
    "Parental_Education_enc": "Parent literacy workshops; bilingual communication",
    "Tutoring_Support":    "Connect with free tutoring centre on campus",
    "Internet_Access":     "Provide campus Wi-Fi access; offline study packs",
    "Extracurricular":     "Recommend clubs for motivation & social integration",
    "Health_Score":        "Refer to school nurse; flexible deadline policy",
}

for ri2, row in feat_imp.iterrows():
    er = ri2 + 10
    bg = LIGHT_BLUE if ri2 < 3 else (WHITE if ri2 % 2 == 0 else GRAY_BG)
    val(ws6.cell(er, 1), row["Feature"], bg=bg, center=False, bold=(ri2<3))
    val(ws6.cell(er, 2), f"{row['Importance']*100:.1f}%", bg=bg)
    ws6.merge_cells(f"C{er}:F{er}")
    c = ws6.cell(er, 3)
    val(c, suggestions.get(row["Feature"], ""), bg=bg, center=False, wrap=True, size=9)
    ws6.row_dimensions[er].height = 22

border_range(ws6, 9, 9 + len(feat_imp), 1, 6)
set_widths(ws6, {"A":18,"B":14,"C":22,"D":20,"E":14,"F":14})

# Save
OUTPUT = "/mnt/user-data/outputs/Student_Performance_Prediction_System.xlsx"
wb.save(OUTPUT)
print(f"\n✅ Excel report saved → {OUTPUT}")
